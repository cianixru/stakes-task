--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.4
-- Dumped by pg_dump version 11.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United Kingdom.1252' LC_CTYPE = 'English_United Kingdom.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: adminpack; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS adminpack WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION adminpack; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION adminpack IS 'administrative functions for PostgreSQL';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.events (
    event_id integer,
    production_no character varying,
    phase character varying,
    venue character varying,
    event_date character varying,
    image_filename character varying,
    logged_by character varying,
    sport character varying,
    originator character varying,
    title character varying,
    created_date character varying,
    name text,
    event_notes text,
    modified_date character varying
);


ALTER TABLE public.events OWNER TO postgres;

--
-- Name: logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.logs (
    event_id bigint,
    log_id character varying,
    timecode character varying,
    description text,
    tape_no character varying
);


ALTER TABLE public.logs OWNER TO postgres;

--
-- Name: tapes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tapes (
    barcode character varying,
    production_no character varying,
    tape_no character varying,
    status character varying,
    format character varying,
    tv_standard character varying,
    a1 character varying,
    a2 character varying,
    a3 character varying,
    a4 character varying,
    record_date character varying,
    notes character varying,
    in_tx character varying,
    in_vtlib character varying,
    sub_title character varying,
    title character varying,
    itsproduction_no character varying,
    created_date character varying,
    modified_date character varying
);


ALTER TABLE public.tapes OWNER TO postgres;

--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.events (event_id, production_no, phase, venue, event_date, image_filename, logged_by, sport, originator, title, created_date, name, event_notes, modified_date) FROM stdin;
\.
COPY public.events (event_id, production_no, phase, venue, event_date, image_filename, logged_by, sport, originator, title, created_date, name, event_notes, modified_date) FROM '$$PATH$$/2816.dat';

--
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.logs (event_id, log_id, timecode, description, tape_no) FROM stdin;
\.
COPY public.logs (event_id, log_id, timecode, description, tape_no) FROM '$$PATH$$/2817.dat';

--
-- Data for Name: tapes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tapes (barcode, production_no, tape_no, status, format, tv_standard, a1, a2, a3, a4, record_date, notes, in_tx, in_vtlib, sub_title, title, itsproduction_no, created_date, modified_date) FROM stdin;
\.
COPY public.tapes (barcode, production_no, tape_no, status, format, tv_standard, a1, a2, a3, a4, record_date, notes, in_tx, in_vtlib, sub_title, title, itsproduction_no, created_date, modified_date) FROM '$$PATH$$/2818.dat';

--
-- PostgreSQL database dump complete
--

